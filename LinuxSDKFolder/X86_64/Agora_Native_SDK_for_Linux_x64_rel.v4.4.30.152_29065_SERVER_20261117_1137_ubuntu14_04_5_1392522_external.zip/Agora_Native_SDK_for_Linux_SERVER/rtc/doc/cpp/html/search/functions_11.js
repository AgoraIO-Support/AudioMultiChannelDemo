var searchData=
[
  ['querycamerafocallengthcapability_7760',['queryCameraFocalLengthCapability',['../classagora_1_1rtc_1_1_i_rtc_engine.html#ac39752567b7b7ac0a2550d42187b1c90',1,'agora::rtc::IRtcEngine']]],
  ['querychannel_7761',['queryChannel',['../classagora_1_1rtc_1_1_i_h265_transcoder.html#a7bf1bb91923b18c00f17158b277337c7',1,'agora::rtc::IH265Transcoder']]],
  ['querycodeccapability_7762',['queryCodecCapability',['../classagora_1_1rtc_1_1_i_rtc_engine.html#a32294dda5cf780cd010dc6f4966957f2',1,'agora::rtc::IRtcEngine']]],
  ['querydevicescore_7763',['queryDeviceScore',['../classagora_1_1rtc_1_1_i_rtc_engine.html#a449e18c0f358915d93f33d84ba076aa3',1,'agora::rtc::IRtcEngine']]],
  ['querydoc_7764',['queryDoc',['../classagora_1_1base_1_1_i_sync_client.html#ad0c0d00b8f69e5cfcd3f9b0bd67ea874',1,'agora::base::ISyncClient']]],
  ['querydocllapiinternal_7765',['queryDocLLApiInternal',['../classagora_1_1base_1_1_i_sync_client_ex.html#a9aa7c67065ecbbfbc5f85a5907da53d4',1,'agora::base::ISyncClientEx']]],
  ['queryinterface_7766',['queryInterface',['../classagora_1_1util_1_1_auto_ptr.html#a264095d02f29ca4f1dfe5a0fa6a9d77b',1,'agora::util::AutoPtr::queryInterface()'],['../classagora_1_1base_1_1_i_engine_base.html#a2241d01eb43195800ed2e67652501e3d',1,'agora::base::IEngineBase::queryInterface()'],['../classagora_1_1rtc_1_1_i_rtc_engine.html#a72d3f2bd9d94e1013fbf777790ac1447',1,'agora::rtc::IRtcEngine::queryInterface()']]],
  ['queryscreencapturecapability_7767',['queryScreenCaptureCapability',['../classagora_1_1rtc_1_1_i_rtc_engine.html#ad59d3a7e70042f94a53229a8cb19a75e',1,'agora::rtc::IRtcEngine']]]
];
