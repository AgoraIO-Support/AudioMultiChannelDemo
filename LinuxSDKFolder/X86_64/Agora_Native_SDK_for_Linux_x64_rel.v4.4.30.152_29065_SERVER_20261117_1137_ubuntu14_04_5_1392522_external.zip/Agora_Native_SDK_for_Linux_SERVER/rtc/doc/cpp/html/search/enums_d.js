var searchData=
[
  ['peer_5fmessage_5fstate_10577',['PEER_MESSAGE_STATE',['../namespaceagora_1_1rtm.html#a35b24ab1df1888fbae835187344f5e63',1,'agora::rtm']]],
  ['permission_5ftype_10578',['PERMISSION_TYPE',['../namespaceagora_1_1rtc.html#a4b7fee76a230060d0389529c66d66ca9',1,'agora::rtc']]],
  ['player_5fpreload_5fevent_10579',['PLAYER_PRELOAD_EVENT',['../namespaceagora_1_1media_1_1base.html#a5899814fce6dde76ac7621cbe2580c78',1,'agora::media::base']]],
  ['primaryid_10580',['PrimaryID',['../structagora_1_1media_1_1base_1_1_color_space.html#ad4d1d446ec52eadae16de778bc318b88',1,'agora::media::base::ColorSpace']]],
  ['priority_5ftype_10581',['PRIORITY_TYPE',['../namespaceagora_1_1rtc.html#a952d84d4fb6affb196d676908bb09d1c',1,'agora::rtc']]],
  ['processmode_10582',['ProcessMode',['../classagora_1_1rtc_1_1_i_extension_video_filter.html#aa187e84d0209376f502044a007e62e1a',1,'agora::rtc::IExtensionVideoFilter']]],
  ['processresult_10583',['ProcessResult',['../classagora_1_1rtc_1_1_i_extension_video_filter.html#acd051db7e29fd23adbf1e15221bc65b9',1,'agora::rtc::IExtensionVideoFilter::ProcessResult()'],['../classagora_1_1rtc_1_1_i_lip_sync_filter.html#ab28883753d96914433da7f28edc2d253',1,'agora::rtc::ILipSyncFilter::ProcessResult()']]],
  ['proxy_5ftype_10584',['PROXY_TYPE',['../namespaceagora_1_1rtc.html#a3814119b658d6ef9c31c718052becb6e',1,'agora::rtc']]],
  ['publishaudioerror_10585',['PublishAudioError',['../namespaceagora_1_1rtc.html#ae1713f658284be303aaa022bcf018d47',1,'agora::rtc']]],
  ['publishvideoerror_10586',['PublishVideoError',['../namespaceagora_1_1rtc.html#a68e2825c220df8afbe45a98f59ccd63e',1,'agora::rtc']]]
];
