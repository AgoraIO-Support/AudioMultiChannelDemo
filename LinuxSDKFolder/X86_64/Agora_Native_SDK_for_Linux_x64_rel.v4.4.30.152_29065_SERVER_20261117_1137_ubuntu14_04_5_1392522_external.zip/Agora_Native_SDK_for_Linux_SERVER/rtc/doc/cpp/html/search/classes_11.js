var searchData=
[
  ['uplinknetworkinfo_6521',['UplinkNetworkInfo',['../structagora_1_1rtc_1_1_uplink_network_info.html',1,'agora::rtc']]],
  ['useraudiospectruminfo_6522',['UserAudioSpectrumInfo',['../structagora_1_1media_1_1_user_audio_spectrum_info.html',1,'agora::media']]],
  ['userdatachannelinfo_6523',['UserDataChannelInfo',['../structagora_1_1_user_data_channel_info.html',1,'agora']]],
  ['userinfo_6524',['UserInfo',['../structagora_1_1_user_info.html',1,'agora::UserInfo'],['../structagora_1_1rtc_1_1_user_info.html',1,'agora::rtc::UserInfo']]]
];
