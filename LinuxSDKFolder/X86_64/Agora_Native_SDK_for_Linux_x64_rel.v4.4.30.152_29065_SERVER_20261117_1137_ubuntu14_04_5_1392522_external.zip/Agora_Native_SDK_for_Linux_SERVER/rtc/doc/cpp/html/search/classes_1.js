var searchData=
[
  ['beautyoptions_6135',['BeautyOptions',['../structagora_1_1rtc_1_1_beauty_options.html',1,'agora::rtc::BeautyOptions'],['../structagora_1_1rtc_1_1_i_video_beauty_filter_1_1_beauty_options.html',1,'agora::rtc::IVideoBeautyFilter::BeautyOptions']]],
  ['bitrateconstraints_6136',['BitrateConstraints',['../structagora_1_1rtc_1_1_bitrate_constraints.html',1,'agora::rtc']]],
  ['broadcast_5fpacket_5ft_6137',['broadcast_packet_t',['../structagora_1_1rtc_1_1broadcast__packet__t.html',1,'agora::rtc']]]
];
