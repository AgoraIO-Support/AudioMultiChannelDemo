var searchData=
[
  ['oboe_5finput_5fand_5foboe_5foutput_11608',['OBOE_INPUT_AND_OBOE_OUTPUT',['../namespaceagora_1_1rtc.html#aef50c3e29519a883dc1a0d4a87889096a84e8e631ce9059181782dbef91a2b869',1,'agora::rtc']]],
  ['open_5fchannel_5fsuccess_11609',['OPEN_CHANNEL_SUCCESS',['../namespaceagora_1_1rtc.html#ae78dcf0b0e9e1b226c9710f8f6ba6f9fae8c0322255fddbad1e698e130cd830cf',1,'agora::rtc']]],
  ['opensl_5finput_5fand_5fopensl_5foutput_11610',['OPENSL_INPUT_AND_OPENSL_OUTPUT',['../namespaceagora_1_1rtc.html#aef50c3e29519a883dc1a0d4a87889096a7cdb09f5a30a8c49259e59b440f7aedb',1,'agora::rtc']]],
  ['opusmc_11611',['OPUSMC',['../namespaceagora_1_1capability.html#a1e7dfb22ff91aa9f43e6dea5f0da4361ad2dc36436b4f3188419f96757932900d',1,'agora::capability']]],
  ['orientation_5fmode_5fadaptive_11612',['ORIENTATION_MODE_ADAPTIVE',['../namespaceagora_1_1rtc.html#af3d825e24a1e5dcfb74279c69b81d0c7a6c9c916656d47771664b0696fbaa39bc',1,'agora::rtc']]],
  ['orientation_5fmode_5ffixed_5flandscape_11613',['ORIENTATION_MODE_FIXED_LANDSCAPE',['../namespaceagora_1_1rtc.html#af3d825e24a1e5dcfb74279c69b81d0c7ac8e505f519b124299c5977b21df29c21',1,'agora::rtc']]],
  ['orientation_5fmode_5ffixed_5fportrait_11614',['ORIENTATION_MODE_FIXED_PORTRAIT',['../namespaceagora_1_1rtc.html#af3d825e24a1e5dcfb74279c69b81d0c7a26abe8e035ec0867b3603ffccc9248f8',1,'agora::rtc']]],
  ['original_11615',['ORIGINAL',['../structagora_1_1rtc_1_1_audio_enc_frame_recv_params.html#ab0fb4c870e62353b3210933a4c82af7eaab500ab025eba425dc5d14994afc1da2',1,'agora::rtc::AudioEncFrameRecvParams']]]
];
