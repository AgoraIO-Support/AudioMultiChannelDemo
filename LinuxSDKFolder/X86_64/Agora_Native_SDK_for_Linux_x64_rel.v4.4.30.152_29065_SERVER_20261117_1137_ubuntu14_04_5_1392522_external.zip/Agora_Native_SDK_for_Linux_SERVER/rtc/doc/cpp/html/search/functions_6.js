var searchData=
[
  ['faceshapeareaoptions_6989',['FaceShapeAreaOptions',['../structagora_1_1rtc_1_1_face_shape_area_options.html#a4ed525f80f36105b93caacb8d0563d3d',1,'agora::rtc::FaceShapeAreaOptions::FaceShapeAreaOptions(FACE_SHAPE_AREA shapeArea, int areaIntensity)'],['../structagora_1_1rtc_1_1_face_shape_area_options.html#ad58497de7770e1910b5bd45198c1ab6b',1,'agora::rtc::FaceShapeAreaOptions::FaceShapeAreaOptions()']]],
  ['faceshapebeautyoptions_6990',['FaceShapeBeautyOptions',['../structagora_1_1rtc_1_1_face_shape_beauty_options.html#adf412b933d00187e80eb2addb0f5fce1',1,'agora::rtc::FaceShapeBeautyOptions::FaceShapeBeautyOptions(FACE_SHAPE_BEAUTY_STYLE shapeStyle, int styleIntensity)'],['../structagora_1_1rtc_1_1_face_shape_beauty_options.html#aea545c09c5c6ef826954344bd5c1261c',1,'agora::rtc::FaceShapeBeautyOptions::FaceShapeBeautyOptions()']]],
  ['fillvideoframedata_6991',['fillVideoFrameData',['../classagora_1_1rtc_1_1_i_video_frame.html#a8ae288082f7e6024ecc81c8921a85b1e',1,'agora::rtc::IVideoFrame']]],
  ['fillvideoframemetadata_6992',['fillVideoFrameMetaData',['../classagora_1_1rtc_1_1_i_video_frame.html#ad6f4341666086d02f15cc7ceb2a312b7',1,'agora::rtc::IVideoFrame']]],
  ['filter_6993',['Filter',['../structagora_1_1rtc_1_1_audio_options.html#ae4e95775ece7178485758f233de8b001',1,'agora::rtc::AudioOptions']]],
  ['fireevent_6994',['fireEvent',['../classagora_1_1rtc_1_1_i_extension_control.html#ae4e07afc457b56c8aa6cafcb543eb0a2',1,'agora::rtc::IExtensionControl']]],
  ['focusonselectedsource_6995',['FocusOnSelectedSource',['../classagora_1_1rtc_1_1_i_screen_capturer_ex.html#a9eea5e81a05041a2b596a2b7b0ccac9d',1,'agora::rtc::IScreenCapturerEx']]],
  ['followsystemloopbackdevice_6996',['followSystemLoopbackDevice',['../classagora_1_1rtc_1_1_i_n_g_audio_device_manager.html#a0373fb56e549c6581cbf18b15ce1eac3',1,'agora::rtc::INGAudioDeviceManager']]],
  ['followsystemplaybackdevice_6997',['followSystemPlaybackDevice',['../classagora_1_1rtc_1_1_i_n_g_audio_device_manager.html#a8ba72b752dcbe625f0762cbf6d2574f5',1,'agora::rtc::INGAudioDeviceManager']]],
  ['followsystemrecordingdevice_6998',['followSystemRecordingDevice',['../classagora_1_1rtc_1_1_i_n_g_audio_device_manager.html#ad0f79771538427a15cc8282f965143d1',1,'agora::rtc::INGAudioDeviceManager']]],
  ['forcedevicescore_6999',['forceDeviceScore',['../classagora_1_1rtc_1_1_i_local_user_ex.html#a5f23a1ef334b75799a128f1a02bf9f2c',1,'agora::rtc::ILocalUserEx']]],
  ['forcedusingscreencapture_7000',['ForcedUsingScreenCapture',['../classagora_1_1rtc_1_1_i_screen_capturer_ex.html#a657ca60979b642cd5854a0fcf2dfbf81',1,'agora::rtc::IScreenCapturerEx']]],
  ['forcenextintraframe_7001',['forceNextIntraFrame',['../classagora_1_1rtc_1_1_i_local_user.html#ac394eae3f088dcb2f59688e9812a4059',1,'agora::rtc::ILocalUser']]],
  ['forcenextintraframellapiinternal_7002',['forceNextIntraFrameLLApiInternal',['../classagora_1_1rtc_1_1_i_local_user_ex.html#abc216ca95edbd12a6bb04a5a8c2651f4',1,'agora::rtc::ILocalUserEx']]],
  ['forceperiodickeyframe_7003',['ForcePeriodicKeyFrame',['../classagora_1_1rtc_1_1_i_local_user_ex.html#a887b72ce3c4dd53998a326dcdece7cfb',1,'agora::rtc::ILocalUserEx']]],
  ['frameprocessresult_7004',['FrameProcessResult',['../structagora_1_1rtc_1_1_frame_process_result.html#ae7744075731b0a4058227cc7a0d4d75e',1,'agora::rtc::FrameProcessResult']]],
  ['freeifneeded_7005',['FreeIfNeeded',['../classagora_1_1internal_1_1_optional_base.html#a3e9337cdb2bf14d0085db7bf79332937',1,'agora::internal::OptionalBase']]],
  ['fromvidetype_7006',['fromVideType',['../structagora_1_1rtc_1_1video__packet__t.html#a29e478fb46cb93b25dc4b4a69c4cb878',1,'agora::rtc::video_packet_t']]]
];
